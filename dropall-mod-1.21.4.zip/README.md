# Drop All Mod (Minecraft 1.21.4 Fabric)

Клиентский мод для Minecraft 1.21.4 Fabric, добавляющий кнопку "Drop All" в инвентарь игрока.

## Сборка
```bash
./gradlew build
```
Готовый .jar файл появится в `build/libs/`.
